package com.cotemig;

public class Aluno {

    public int idAluno;
    public String nome;
    public boolean matriculado;
    public int idade;
    public String curso;

    public Aluno(int idAluno, String nome, boolean matriculado, int idade, String curso){
        this.idAluno = idAluno;
        this.nome = nome;
        this.matriculado = false;
        this.idade = idade;
        this.curso = curso;
    }

    public void matricular(){
        matriculado = true;
        System.out.println("Aluno " + this.nome + " foi matriculado!!");
    }


}
