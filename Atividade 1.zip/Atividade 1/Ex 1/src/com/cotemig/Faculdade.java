package com.cotemig;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Faculdade {

    Scanner input = new Scanner(System.in);

    public int idFaculdade;
    public String nome;
    public String cnpj;
    public String diretor;
    public String local;
    public List<Aluno> alunos;

    public Faculdade(int idFaculdade, String nome, String cnpj, String diretor, String local){
        this.idFaculdade = idFaculdade;
        this.nome= nome;
        this.cnpj = cnpj;
        this.diretor = diretor;
        this.local = local;
        alunos = new ArrayList<>();
    }

    public void addAluno(Aluno aluno){
        this.alunos.add(aluno);
    }

    public void atualizarLocal(){
        System.out.println("Escreva o novo endereço");
        this.local = input.nextLine();
    }

    public void exibirInfo(){
        System.out.println("Local: " + this.local);

    }

}
