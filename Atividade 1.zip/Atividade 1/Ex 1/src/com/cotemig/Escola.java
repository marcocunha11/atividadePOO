package com.cotemig;

public class Escola {

    public int idEscola;
    public String nome;
    public char cnpj;
    public String diretor;
    public String local;

    public Escola(int idEscola, String nome, char cnpj, String diretor, String local){
        this.idEscola = idEscola;
        this.nome = nome;
        this.cnpj = cnpj;
        this.diretor = diretor;
        this.local = local;
    }
}
