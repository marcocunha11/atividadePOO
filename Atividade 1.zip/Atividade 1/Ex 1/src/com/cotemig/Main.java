package com.cotemig;

import jdk.internal.util.xml.impl.Input;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Aluno a1 = new Aluno(1,"Marco",false, 19,"CC");
        Aluno a2 = new Aluno(2,"Milena",true, 19,"ADS");
        Aluno a3 = new Aluno(3,"Coração",false, 22,"OBA");

        //a1.matricular();
        //a1.exibirAluno();
        //a2.exibirAluno();
        Scanner input = new Scanner(System.in);

        Faculdade f1 = new Faculdade(1,"Cotemig","01.000.000/0001-99", "Diretor 1","Rua Gustaf Dalen, 151 - Distrito");


        f1.exibirInfo();

        f1.atualizarLocal();

        f1.exibirInfo();


    }

}
