package com.cotemig;

import com.sun.deploy.uitoolkit.impl.awt.AWTDefaultPreloader;

public class Onibus {

    public double kmRodado;
    public int qtdPessoas;
    public String motorista;

    public Onibus(int qtdPessoas){
        this.qtdPessoas = qtdPessoas;

    }

    public boolean getkmRodado(){
        if(this.kmRodado > 200){
            System.out.println("com.cotemig.Onibus impossobilitado de rodar");
            return false;
        }
        else{
            System.out.println("O veículo pode rodar");
            return true;
        }
    }

    public void addPessoas(int qtdPessoas){
        if((this.qtdPessoas + qtdPessoas) <= 60){
            this.qtdPessoas += qtdPessoas;
        }
        else{
            System.out.println("Limite máximo atingido!");
        }

    }

    public void removePessoa(){
        if(this.qtdPessoas > 0){
            this.qtdPessoas--;
        }
        else{
            System.out.println("com.cotemig.Onibus possui 0 pessoas");
        }
    }

    public void trocaMotorista(String motorista){
        this.motorista = motorista;
    }




}
