package com.cotemig;

public class Main {

    public static void main(String[] args) {

        Empresa emp = new Empresa("Empresa com.cotemig.Onibus", "9218357");


        Onibus o1 = new Onibus(2);
        Onibus o2 = new Onibus(12);
        Onibus o3 = new Onibus(20);

        emp.addOnibus(o1);
        emp.addOnibus(o2);
        emp.addOnibus(o3);

        o3.getkmRodado();

        o2.addPessoas(7);

        o3.addPessoas(69);
        o3.removePessoa();

        o3.trocaMotorista("Jose");

    }
}
