package com.cotemig;

import java.util.ArrayList;
import java.util.List;

public class Empresa {

    public String nome;
    public String cnpj;
    public List<Onibus> frotaOnibus;

    public Empresa(String nome, String cnpj){
        this.nome= nome;
        this.cnpj = cnpj;
        frotaOnibus = new ArrayList<>();
    }

    public void addOnibus(Onibus onibus){
        this.frotaOnibus.add(onibus);

    }

}
