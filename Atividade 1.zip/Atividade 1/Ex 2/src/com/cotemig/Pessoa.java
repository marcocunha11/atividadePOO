package com.cotemig;

public class Pessoa {
}
